const WebSocket = require('ws');
const mongoose = require('mongoose')
const url = 'mongodb+srv://admin:admin@cluster1.3rs4n9j.mongodb.net/';

// Connect to MongoDB
mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected successfully to MongoDB'))
  .catch(err => console.error('Connection error', err));

// Define a schema
const signalSchema = new mongoose.Schema({
  number: String,
  date: String
});

// Create a model
const Signal = mongoose.model('Signal', signalSchema);    

const ws = new WebSocket('ws://localhost:8080');

ws.on('open', () => {
  console.log('Connected to server');

  // Send a message to the server
  ws.send('Hello from client');

  // Close the connection after a 10-second delay
  setTimeout(() => {
    ws.close();
  }, 50000);
});

ws.on('message', (message) => {
  console.log(`Received: ${message}`);
  // Save the document to the collection

  const newSignal = new Signal({
    number:message,date:new Date().toISOString()
  });  

newSignal.save()
.then(doc => {
  console.log(`New document inserted with _id: ${doc._id}`);
})
.catch(err => console.error('Error inserting document', err));
});

ws.on('close', () => {
  console.log('Disconnected from server');
});
